# Roube um Brainrot (base)

Jogo para Roblox Studio no estilo "Roube um Brainrot". Um único script gera o mapa, as bases, a esteira, a compra, o roubo, a trava de base e o salvamento.

## Como usar (sem Rojo)
1. Abra o Roblox Studio com o template **Baseplate**.
2. Crie um **Script** em `ServerScriptService`.
3. Cole o conteúdo de `src/ServerScriptService/GameServer.server.lua`.
4. Aperte **F5**. Para testar o roubo: **Test > Clients and Servers** com 2 jogadores.

## Como usar (com Rojo)
```
rojo serve
```
Depois conecte pelo plugin do Rojo no Studio.

## Salvamento
Ative **Game Settings > Security > Enable Studio Access to API Services** para testar o DataStore no Studio.

## Configuração
Edite `CFG` e a lista `BRAINROTS` no início do script (preços, renda, chance, velocidade da esteira).
