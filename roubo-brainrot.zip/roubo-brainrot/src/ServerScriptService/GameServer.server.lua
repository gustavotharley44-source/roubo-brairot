--[[
  ROUBE UM BRAINROT (versão base) - Roblox Studio
  Onde colocar: ServerScriptService > Script (Script normal, NÃO LocalScript)
  Template recomendado: Baseplate. O script gera o mapa inteiro sozinho.

  Como o jogo funciona:
  1. Uma esteira gera brainrots com preços diferentes (os raros são mais caros).
  2. Você compra com o dinheiro (Cash) e ele vai para um slot da sua base.
  3. Cada brainrot rende dinheiro por segundo.
  4. Outros jogadores podem ROUBAR da sua base (segurar E), levar para a base deles e depositar.
  5. Na sua base tem um botão verde para TRANCAR a base por 30s.
  6. Cash e brainrots são salvos (DataStore).
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local DataStoreService = game:GetService("DataStoreService")

local store = DataStoreService:GetDataStore("RouboBrainrot_v1")

---------------------------------------------------------------------
-- CONFIGURAÇÃO (mexa à vontade)
---------------------------------------------------------------------
local CFG = {
	MaxBases = 6,
	SlotsPerBase = 6,
	StartCash = 100,
	SpawnInterval = 4,     -- segundos entre cada brainrot na esteira
	ConveyorSpeed = 12,    -- studs por segundo
	ConveyorLength = 120,
	LockDuration = 30,     -- segundos de base trancada
	StealTime = 1.5,       -- segundos segurando para roubar
}

-- Weight = chance relativa de aparecer na esteira
local BRAINROTS = {
	{ Name = "Pãozinho Ninja",     Price = 50,     Income = 2,    Weight = 40, Color = Color3.fromRGB(255, 190, 90) },
	{ Name = "Coxinha Turbo",      Price = 250,    Income = 8,    Weight = 30, Color = Color3.fromRGB(255, 140, 40) },
	{ Name = "Gato Caipira",       Price = 1000,   Income = 25,   Weight = 18, Color = Color3.fromRGB(120, 200, 255) },
	{ Name = "Jacaré Foguete",     Price = 5000,   Income = 100,  Weight = 8,  Color = Color3.fromRGB(80, 220, 120) },
	{ Name = "Vaca Cósmica",       Price = 25000,  Income = 450,  Weight = 3,  Color = Color3.fromRGB(190, 110, 255) },
	{ Name = "Capivara Lendária",  Price = 150000, Income = 2500, Weight = 1,  Color = Color3.fromRGB(255, 215, 0) },
}

local byName, totalWeight = {}, 0
for _, b in ipairs(BRAINROTS) do
	byName[b.Name] = b
	totalWeight += b.Weight
end

---------------------------------------------------------------------
-- FUNÇÕES AUXILIARES
---------------------------------------------------------------------
local function pickRandom()
	local r = math.random() * totalWeight
	for _, b in ipairs(BRAINROTS) do
		r -= b.Weight
		if r <= 0 then return b end
	end
	return BRAINROTS[1]
end

local function fmt(n)
	if n >= 1e6 then return string.format("%.1fM", n / 1e6)
	elseif n >= 1e3 then return string.format("%.1fK", n / 1e3) end
	return tostring(n)
end

local function newPart(props, parent)
	local p = Instance.new("Part")
	p.Anchored = true
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	for k, v in pairs(props) do p[k] = v end
	p.Parent = parent
	return p
end

local function label(parent, text, offset, width)
	local gui = Instance.new("BillboardGui")
	gui.Size = UDim2.fromOffset(width or 220, 70)
	gui.StudsOffset = Vector3.new(0, offset or 3, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = 80
	gui.Parent = parent
	local t = Instance.new("TextLabel")
	t.Size = UDim2.fromScale(1, 1)
	t.BackgroundTransparency = 1
	t.TextScaled = true
	t.Font = Enum.Font.FredokaOne
	t.TextColor3 = Color3.new(1, 1, 1)
	t.TextStrokeTransparency = 0
	t.Text = text
	t.Parent = gui
	return t
end

local function weld(a, b)
	local w = Instance.new("WeldConstraint")
	w.Part0 = a
	w.Part1 = b
	w.Parent = a
end

-- Cria o modelo do brainrot (corpo + cabeça + olhos)
local function createBrainrotModel(data)
	local m = Instance.new("Model")
	m.Name = data.Name

	local body = Instance.new("Part")
	body.Name = "Corpo"
	body.Size = Vector3.new(3, 4, 3)
	body.Color = data.Color
	body.Material = Enum.Material.SmoothPlastic
	body.Anchored = true
	body.Parent = m

	local head = Instance.new("Part")
	head.Name = "Cabeca"
	head.Shape = Enum.PartType.Ball
	head.Size = Vector3.new(3.4, 3.4, 3.4)
	head.Color = data.Color
	head.Material = Enum.Material.SmoothPlastic
	head.CFrame = body.CFrame * CFrame.new(0, 3.2, 0)
	head.Parent = m
	weld(body, head)

	for _, ox in ipairs({ -0.6, 0.6 }) do
		local eye = Instance.new("Part")
		eye.Shape = Enum.PartType.Ball
		eye.Size = Vector3.new(0.9, 0.9, 0.9)
		eye.Color = Color3.new(1, 1, 1)
		eye.CFrame = head.CFrame * CFrame.new(ox, 0.3, -1.45)
		eye.Parent = m
		weld(head, eye)
		local pupil = Instance.new("Part")
		pupil.Shape = Enum.PartType.Ball
		pupil.Size = Vector3.new(0.4, 0.4, 0.4)
		pupil.Color = Color3.new(0, 0, 0)
		pupil.CFrame = eye.CFrame * CFrame.new(0, 0, -0.4)
		pupil.Parent = m
		weld(eye, pupil)
	end

	m.PrimaryPart = body
	return m
end

local function newPrompt(parent, action, object, hold, dist)
	local p = Instance.new("ProximityPrompt")
	p.Name = "Prompt"
	p.ActionText = action
	p.ObjectText = object
	p.HoldDuration = hold or 0
	p.MaxActivationDistance = dist or 10
	p.RequiresLineOfSight = false
	p.Parent = parent
	return p
end

---------------------------------------------------------------------
-- MUNDO (gerado por script)
---------------------------------------------------------------------
local oldBase = workspace:FindFirstChild("Baseplate")
if oldBase then oldBase:Destroy() end
local oldSpawn = workspace:FindFirstChildOfClass("SpawnLocation")
if oldSpawn then oldSpawn:Destroy() end

local world = Instance.new("Folder")
world.Name = "Mundo"
world.Parent = workspace

newPart({
	Name = "Chao", Size = Vector3.new(400, 1, 300), Position = Vector3.new(0, -0.5, 0),
	Color = Color3.fromRGB(90, 190, 90), Material = Enum.Material.Grass,
}, world)

newPart({
	Name = "Esteira", Size = Vector3.new(CFG.ConveyorLength + 10, 1, 8), Position = Vector3.new(0, 0.1, 0),
	Color = Color3.fromRGB(45, 45, 55), Material = Enum.Material.Metal,
}, world)

local playerState = {} -- [Player] = { Base = base, Carrying = {Model, Data} | nil }
local bases = {}
local freeSlot, placeInSlot, stealFrom

freeSlot = function(base)
	for i, s in ipairs(base.Slots) do
		if not s.Item then return i end
	end
	return nil
end

local function buildBase(i)
	local side = (i <= 3) and -1 or 1
	local x = ((i - 1) % 3 - 1) * 60
	local z = side * 55
	local frontZ = z - side * 15

	local model = Instance.new("Model")
	model.Name = "Base" .. i
	model.Parent = world

	local base = {
		Model = model, Slots = {}, Owner = nil, Locked = false,
		Spawn = CFrame.new(x, 4, z - side * 5),
	}

	base.Floor = newPart({
		Name = "Piso", Size = Vector3.new(50, 1, 30), Position = Vector3.new(x, 0.5, z),
		Color = Color3.fromRGB(235, 235, 235), Material = Enum.Material.SmoothPlastic,
	}, model)

	for s = 1, CFG.SlotsPerBase do
		local pad = newPart({
			Name = "Slot" .. s, Size = Vector3.new(7, 0.4, 7),
			Position = Vector3.new(x - 22 + (s - 1) * 8.8, 1.2, z + side * 6),
			Color = Color3.fromRGB(255, 215, 0), Material = Enum.Material.Neon,
		}, model)
		base.Slots[s] = { Pad = pad, Item = nil }
	end

	local wallColor = Color3.fromRGB(120, 120, 140)
	newPart({ Name = "ParedeEsq", Size = Vector3.new(1, 12, 30), Position = Vector3.new(x - 25, 6, z), Color = wallColor, Transparency = 0.5 }, model)
	newPart({ Name = "ParedeDir", Size = Vector3.new(1, 12, 30), Position = Vector3.new(x + 25, 6, z), Color = wallColor, Transparency = 0.5 }, model)
	local back = newPart({ Name = "ParedeFundo", Size = Vector3.new(50, 12, 1), Position = Vector3.new(x, 6, z + side * 15), Color = wallColor, Transparency = 0.5 }, model)
	base.Sign = label(back, "Base livre", 4, 320)

	-- Barreira da frente (aparece quando a base está trancada)
	base.Barrier = newPart({
		Name = "Barreira", Size = Vector3.new(50, 12, 1), Position = Vector3.new(x, 6, frontZ),
		Color = Color3.fromRGB(255, 50, 50), Material = Enum.Material.Neon,
		Transparency = 1, CanCollide = false,
	}, model)

	-- Botão de trancar
	local lockPad = newPart({
		Name = "BotaoTrancar", Size = Vector3.new(6, 0.4, 4), Position = Vector3.new(x, 1.2, z - side * 11),
		Color = Color3.fromRGB(50, 220, 90), Material = Enum.Material.Neon,
	}, model)
	local lp = newPrompt(lockPad, "Trancar base (" .. CFG.LockDuration .. "s)", "Proteção", 0.5, 8)
	lp.Triggered:Connect(function(plr)
		if base.Owner ~= plr or base.Locked then return end
		base.Locked = true
		base.Barrier.Transparency = 0.3
		base.Barrier.CanCollide = true
		task.delay(CFG.LockDuration, function()
			base.Locked = false
			base.Barrier.Transparency = 1
			base.Barrier.CanCollide = false
		end)
	end)

	-- Depositar brainrot roubado ao pisar na própria base
	base.Floor.Touched:Connect(function(hit)
		local plr = Players:GetPlayerFromCharacter(hit.Parent)
		if not plr then return end
		local st = playerState[plr]
		if not st or st.Base ~= base or not st.Carrying then return end
		local idx = freeSlot(base)
		if not idx then return end
		local c = st.Carrying
		st.Carrying = nil
		c.Model:Destroy()
		placeInSlot(base, idx, c.Data)
	end)

	return base
end

for i = 1, CFG.MaxBases do
	bases[i] = buildBase(i)
end

---------------------------------------------------------------------
-- COLOCAR / ROUBAR
---------------------------------------------------------------------
placeInSlot = function(base, idx, data)
	local slot = base.Slots[idx]
	local m = createBrainrotModel(data)
	m:PivotTo(CFrame.new(slot.Pad.Position + Vector3.new(0, 2.2, 0)))
	m.Parent = base.Model
	label(m.PrimaryPart, data.Name .. "\n+$" .. fmt(data.Income) .. "/s", 6)
	slot.Item = { Model = m, Data = data }

	local p = newPrompt(m.PrimaryPart, "Roubar", data.Name, CFG.StealTime, 9)
	p.Triggered:Connect(function(thief)
		stealFrom(thief, base, idx)
	end)
end

stealFrom = function(thief, base, idx)
	local st = playerState[thief]
	if not st or base.Owner == thief or base.Owner == nil then return end
	if base.Locked or st.Carrying then return end
	local item = base.Slots[idx].Item
	if not item then return end
	local char = thief.Character
	local hrp = char and char:FindFirstChild("HumanoidRootPart")
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if not hrp or not hum or hum.Health <= 0 then return end
	if not freeSlot(st.Base) then return end -- precisa ter slot livre na sua base

	base.Slots[idx].Item = nil
	item.Model:Destroy()

	local m = createBrainrotModel(item.Data)
	for _, part in ipairs(m:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide = false
			part.Massless = true
		end
	end
	m:PivotTo(hrp.CFrame * CFrame.new(0, 5, 0))
	m.Parent = char
	weld(hrp, m.PrimaryPart)
	st.Carrying = { Model = m, Data = item.Data }
end

---------------------------------------------------------------------
-- ESTEIRA
---------------------------------------------------------------------
local belt = {}

local function buy(plr, entry)
	local st = playerState[plr]
	if not st or not entry.Model.Parent then return end
	local cash = plr.leaderstats.Cash
	if cash.Value < entry.Data.Price then return end
	local idx = freeSlot(st.Base)
	if not idx then return end
	entry.Model:Destroy()
	cash.Value -= entry.Data.Price
	placeInSlot(st.Base, idx, entry.Data)
end

task.spawn(function()
	while true do
		task.wait(CFG.SpawnInterval)
		local data = pickRandom()
		local m = createBrainrotModel(data)
		m:PivotTo(CFrame.new(-CFG.ConveyorLength / 2, 3.5, 0))
		m.Parent = world
		label(m.PrimaryPart, data.Name .. "\n$" .. fmt(data.Price) .. "  |  +$" .. fmt(data.Income) .. "/s", 6)
		local entry = { Model = m, Data = data }
		local p = newPrompt(m.PrimaryPart, "Comprar $" .. fmt(data.Price), data.Name, 0.2, 10)
		p.Triggered:Connect(function(plr) buy(plr, entry) end)
		table.insert(belt, entry)
	end
end)

RunService.Heartbeat:Connect(function(dt)
	for i = #belt, 1, -1 do
		local e = belt[i]
		if not e.Model.Parent then
			table.remove(belt, i)
		else
			local cf = e.Model:GetPivot() + Vector3.new(CFG.ConveyorSpeed * dt, 0, 0)
			if cf.X > CFG.ConveyorLength / 2 then
				e.Model:Destroy()
				table.remove(belt, i)
			else
				e.Model:PivotTo(cf)
			end
		end
	end
end)

---------------------------------------------------------------------
-- RENDA POR SEGUNDO
---------------------------------------------------------------------
task.spawn(function()
	while true do
		task.wait(1)
		for plr, st in pairs(playerState) do
			local inc = 0
			for _, s in ipairs(st.Base.Slots) do
				if s.Item then inc += s.Item.Data.Income end
			end
			if inc > 0 and plr:FindFirstChild("leaderstats") then
				plr.leaderstats.Cash.Value += inc
			end
		end
	end
end)

---------------------------------------------------------------------
-- JOGADORES + SALVAMENTO
---------------------------------------------------------------------
local function savePlayer(plr)
	local st = playerState[plr]
	local ls = plr:FindFirstChild("leaderstats")
	if not st or not ls then return end
	local names = {}
	for _, s in ipairs(st.Base.Slots) do
		if s.Item then table.insert(names, s.Item.Data.Name) end
	end
	local data = { Cash = ls.Cash.Value, Slots = names }
	pcall(function() store:SetAsync(tostring(plr.UserId), data) end)
end

local function onPlayerAdded(plr)
	local base
	for _, b in ipairs(bases) do
		if not b.Owner then base = b break end
	end
	if not base then
		plr:Kick("Servidor cheio, tente outro!")
		return
	end
	base.Owner = plr
	base.Sign.Text = "Base de " .. plr.DisplayName
	playerState[plr] = { Base = base, Carrying = nil }

	local ls = Instance.new("Folder")
	ls.Name = "leaderstats"
	ls.Parent = plr
	local cash = Instance.new("IntValue")
	cash.Name = "Cash"
	cash.Value = CFG.StartCash
	cash.Parent = ls

	local ok, saved = pcall(function() return store:GetAsync(tostring(plr.UserId)) end)
	if ok and saved then
		cash.Value = saved.Cash or cash.Value
		for _, name in ipairs(saved.Slots or {}) do
			local d = byName[name]
			local idx = freeSlot(base)
			if d and idx then placeInSlot(base, idx, d) end
		end
	end

	local function onChar(char)
		char:WaitForChild("HumanoidRootPart")
		char:PivotTo(base.Spawn)
		local hum = char:WaitForChild("Humanoid")
		hum.Died:Connect(function()
			if playerState[plr] then playerState[plr].Carrying = nil end
		end)
	end
	plr.CharacterAdded:Connect(onChar)
	if plr.Character then onChar(plr.Character) end
end

local function onPlayerRemoving(plr)
	savePlayer(plr)
	local st = playerState[plr]
	if st then
		local base = st.Base
		for _, s in ipairs(base.Slots) do
			if s.Item then s.Item.Model:Destroy() s.Item = nil end
		end
		base.Owner = nil
		base.Locked = false
		base.Barrier.Transparency = 1
		base.Barrier.CanCollide = false
		base.Sign.Text = "Base livre"
		playerState[plr] = nil
	end
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(onPlayerRemoving)
for _, plr in ipairs(Players:GetPlayers()) do task.spawn(onPlayerAdded, plr) end

-- Autosave a cada 60s
task.spawn(function()
	while true do
		task.wait(60)
		for _, plr in ipairs(Players:GetPlayers()) do savePlayer(plr) end
	end
end)

game:BindToClose(function()
	for _, plr in ipairs(Players:GetPlayers()) do savePlayer(plr) end
end)
